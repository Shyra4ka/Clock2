package com.example.timestopclock;

import com.example.timestopclock.item.TimeStopClockItem;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, TimeStopClockMod.MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, TimeStopClockMod.MOD_ID);

    public static final RegistryObject<Item> TIME_STOP_CLOCK = ITEMS.register("time_stop_clock",
            () -> new TimeStopClockItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<CreativeModeTab> MAIN_TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.timestopclock"))
                    .icon(() -> new ItemStack(TIME_STOP_CLOCK.get()))
                    .displayItems((params, output) -> output.accept(TIME_STOP_CLOCK.get()))
                    .build());

    private ModItems() {}
}
