package com.example.timestopclock.client;

import com.example.timestopclock.TimeStopClockMod;
import com.example.timestopclock.network.SyncPacket;
import com.example.timestopclock.time.TimeStopHold;
import com.example.timestopclock.time.TimeStopState;
import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.ClientLevel;
import net.minecraft.client.renderer.GameRenderer;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

/**
 * Клиентская часть: эффект "The World" (негатив -> серый мир), титул "ЗА ВАРУДО!"
 * и удержание сущностей на месте на стороне клиента.
 */
@Mod.EventBusSubscriber(modid = TimeStopClockMod.MOD_ID, value = Dist.CLIENT)
public final class ClientTimeStop {
    private static final ResourceLocation INVERT = new ResourceLocation("shaders/post/invert.json");
    private static final ResourceLocation DESATURATE = new ResourceLocation("shaders/post/desaturate.json");

    /** Сколько тиков показывать негатив в начале остановки. */
    private static final int FLASH_TICKS = 12;

    private static int ticks;
    /** 0 - нет шейдера, 1 - негатив, 2 - серый. */
    private static int currentShader;

    public static void onSync(SyncPacket msg) {
        TimeStopState st = TimeStopState.CLIENT;
        boolean was = st.stopped;
        st.clear();
        st.stopped = msg.stopped();
        st.owner = msg.stopped() ? msg.owner() : null;
        ticks = 0;

        Minecraft mc = Minecraft.getInstance();
        if (msg.stopped() && !was) {
            mc.gui.setTimes(5, 30, 15);
            mc.gui.setTitle(Component.translatable("title.timestopclock.za_warudo"));
            mc.gui.setSubtitle(Component.translatable("subtitle.timestopclock.stopped"));
        }
        if (!msg.stopped()) {
            setShader(0);
        }
    }

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        TimeStopState st = TimeStopState.CLIENT;

        if (mc.level == null || mc.player == null) {
            st.stopped = false;
            st.owner = null;
            st.clear();
            currentShader = 0;
            return;
        }
        if (!st.stopped) {
            if (currentShader != 0) setShader(0);
            return;
        }

        ticks++;
        boolean isOwner = mc.player.getUUID().equals(st.owner);
        int wanted = ticks <= FLASH_TICKS ? 1 : (isOwner ? 0 : 2);
        if (wanted != currentShader) setShader(wanted);

        List<Entity> list = new ArrayList<>();
        ((ClientLevel) mc.level).entitiesForRendering().forEach(list::add);
        TimeStopHold.hold(list, st);
    }

    private static void setShader(int mode) {
        Minecraft mc = Minecraft.getInstance();
        GameRenderer renderer = mc.gameRenderer;
        currentShader = mode;
        if (mode == 0) {
            renderer.shutdownEffect();
            return;
        }
        loadEffect(renderer, mode == 1 ? INVERT : DESATURATE);
    }

    /** loadEffect может быть приватным в зависимости от маппингов, поэтому вызываем через рефлексию. */
    private static void loadEffect(GameRenderer renderer, ResourceLocation id) {
        try {
            for (Method m : GameRenderer.class.getDeclaredMethods()) {
                Class<?>[] params = m.getParameterTypes();
                boolean byName = m.getName().equals("loadEffect") || m.getName().equals("m_109128_");
                if (byName && params.length == 1 && params[0] == ResourceLocation.class) {
                    m.setAccessible(true);
                    m.invoke(renderer, id);
                    return;
                }
            }
        } catch (Exception ex) {
            // Шейдер - это только украшение, без него мод продолжит работать
            System.err.println("[timestopclock] Could not load post effect " + id + ": " + ex);
        }
    }

    private ClientTimeStop() {}
}
