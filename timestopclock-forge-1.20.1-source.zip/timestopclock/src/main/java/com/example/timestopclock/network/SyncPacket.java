package com.example.timestopclock.network;

import com.example.timestopclock.client.ClientTimeStop;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import net.minecraftforge.network.NetworkEvent;

import java.util.UUID;
import java.util.function.Supplier;

public record SyncPacket(boolean stopped, UUID owner) {

    public static void encode(SyncPacket msg, FriendlyByteBuf buf) {
        buf.writeBoolean(msg.stopped());
        buf.writeUUID(msg.owner() == null ? new UUID(0L, 0L) : msg.owner());
    }

    public static SyncPacket decode(FriendlyByteBuf buf) {
        return new SyncPacket(buf.readBoolean(), buf.readUUID());
    }

    public static void handle(SyncPacket msg, Supplier<NetworkEvent.Context> ctx) {
        ctx.get().enqueueWork(() ->
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ClientTimeStop.onSync(msg)));
        ctx.get().setPacketHandled(true);
    }
}
