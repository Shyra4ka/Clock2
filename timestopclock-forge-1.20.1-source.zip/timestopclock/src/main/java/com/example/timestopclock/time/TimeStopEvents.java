package com.example.timestopclock.time;

import com.example.timestopclock.TimeStopClockMod;
import com.example.timestopclock.network.ModNetwork;
import com.example.timestopclock.network.SyncPacket;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.tags.DamageTypeTags;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.ProjectileImpactEvent;
import net.minecraftforge.event.entity.living.LivingAttackEvent;
import net.minecraftforge.event.entity.living.LivingDeathEvent;
import net.minecraftforge.event.entity.living.LivingEvent;
import net.minecraftforge.event.entity.player.AttackEntityEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;
import net.minecraftforge.event.level.BlockEvent;
import net.minecraftforge.event.server.ServerStoppingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.LogicalSide;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.server.ServerLifecycleHooks;

import java.util.ArrayList;
import java.util.List;

@Mod.EventBusSubscriber(modid = TimeStopClockMod.MOD_ID)
public final class TimeStopEvents {

    /** Мобы (и любые живые существа, кроме игроков) не тикают, пока время остановлено. */
    @SubscribeEvent
    public static void onLivingTick(LivingEvent.LivingTickEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity instanceof Player) return;
        if (TimeStopState.of(entity.level()).isFrozen(entity)) {
            event.setCanceled(true);
        }
    }

    /** Удерживаем стрелы, предметы, TNT и прочее на месте (сервер). */
    @SubscribeEvent
    public static void onLevelTick(TickEvent.LevelTickEvent event) {
        if (event.side != LogicalSide.SERVER || !(event.level instanceof ServerLevel level)) return;
        TimeStopState st = TimeStopState.SERVER;
        if (!st.stopped) return;
        List<Entity> list = new ArrayList<>();
        level.getAllEntities().forEach(list::add);
        TimeStopHold.hold(list, st);
    }

    /** Остальные игроки замирают на месте. */
    @SubscribeEvent
    public static void onServerTick(TickEvent.ServerTickEvent event) {
        if (event.phase != TickEvent.Phase.END) return;
        TimeStopState st = TimeStopState.SERVER;
        if (!st.stopped) return;
        MinecraftServer server = ServerLifecycleHooks.getCurrentServer();
        if (server == null) return;
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            if (p.isSpectator() || !st.isFrozen(p)) continue;
            Vec3 stored = st.pos.computeIfAbsent(p.getUUID(), k -> p.position());
            p.setDeltaMovement(Vec3.ZERO);
            if (p.position().distanceToSqr(stored) > 1.0E-4) {
                p.connection.teleport(stored.x, stored.y, stored.z, p.getYRot(), p.getXRot());
            }
        }
    }

    /** Снаряды в замороженном времени не попадают ни во что. */
    @SubscribeEvent
    public static void onProjectileImpact(ProjectileImpactEvent event) {
        Entity projectile = event.getProjectile();
        if (TimeStopState.of(projectile.level()).isFrozen(projectile)) {
            event.setCanceled(true);
        }
    }

    /** Урон по замороженным целям копится и применяется разом при возобновлении времени. */
    @SubscribeEvent
    public static void onLivingAttack(LivingAttackEvent event) {
        LivingEntity target = event.getEntity();
        if (target.level().isClientSide()) return;
        TimeStopState st = TimeStopState.SERVER;
        if (!st.isFrozen(target)) return;

        DamageSource source = event.getSource();
        if (source.is(DamageTypeTags.BYPASSES_INVULNERABILITY)) return; // /kill, бездна

        event.setCanceled(true);
        Entity attacker = source.getEntity();
        if (attacker != null && attacker.getUUID().equals(st.owner)) {
            st.pending.computeIfAbsent(target.getUUID(), k -> new TimeStopState.Pending(source)).amount
                    += event.getAmount();
        }
    }

    // ---- Замороженные игроки ничего не могут делать ----

    @SubscribeEvent
    public static void onInteract(PlayerInteractEvent event) {
        Player p = event.getEntity();
        if (event.isCancelable() && TimeStopState.of(p.level()).isFrozen(p)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onAttackEntity(AttackEntityEvent event) {
        Player p = event.getEntity();
        if (TimeStopState.of(p.level()).isFrozen(p)) {
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onBlockBreak(BlockEvent.BreakEvent event) {
        Player p = event.getPlayer();
        if (TimeStopState.SERVER.isFrozen(p)) {
            event.setCanceled(true);
        }
    }

    // ---- Жизненный цикл ----

    @SubscribeEvent
    public static void onLogin(PlayerEvent.PlayerLoggedInEvent event) {
        if (event.getEntity() instanceof ServerPlayer sp) {
            TimeStopState st = TimeStopState.SERVER;
            ModNetwork.sendTo(sp, new SyncPacket(st.stopped, st.owner));
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        TimeStopState st = TimeStopState.SERVER;
        if (st.stopped && event.getEntity() instanceof ServerPlayer sp && sp.getUUID().equals(st.owner)) {
            TimeStopManager.resume(sp.server);
        }
    }

    @SubscribeEvent
    public static void onDeath(LivingDeathEvent event) {
        TimeStopState st = TimeStopState.SERVER;
        if (st.stopped && event.getEntity() instanceof ServerPlayer sp && sp.getUUID().equals(st.owner)) {
            TimeStopManager.resume(sp.server);
        }
    }

    @SubscribeEvent
    public static void onServerStopping(ServerStoppingEvent event) {
        TimeStopManager.resume(event.getServer());
    }

    private TimeStopEvents() {}
}
