package com.example.timestopclock.time;

import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.item.PrimedTnt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.UUID;

/** Удерживает замороженные сущности на месте (стрелы, предметы, TNT, лодки и т.д.). */
public final class TimeStopHold {

    public static void hold(Iterable<Entity> entities, TimeStopState st) {
        for (Entity e : entities) {
            if (e instanceof Player || e.isRemoved() || e.isPassenger() || !st.isFrozen(e)) continue;

            UUID id = e.getUUID();
            Vec3 p = st.pos.get(id);
            if (p == null) {
                p = e.position();
                st.pos.put(id, p);
                st.vel.put(id, e.getDeltaMovement());
                if (e instanceof PrimedTnt tnt) st.fuse.put(id, tnt.getFuse());
            }

            e.setDeltaMovement(Vec3.ZERO);
            if (e.getX() != p.x || e.getY() != p.y || e.getZ() != p.z) {
                e.setPos(p.x, p.y, p.z);
            }
            if (e instanceof PrimedTnt tnt) {
                Integer f = st.fuse.get(id);
                if (f != null) tnt.setFuse(f);
            }
        }
    }

    private TimeStopHold() {}
}
