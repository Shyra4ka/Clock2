package com.example.timestopclock.time;

import com.example.timestopclock.network.ModNetwork;
import com.example.timestopclock.network.SyncPacket;
import net.minecraft.network.chat.Component;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.GameRules;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;

/** Серверная логика: остановка и возобновление времени. */
public final class TimeStopManager {

    public static void toggle(ServerPlayer player) {
        TimeStopState st = TimeStopState.SERVER;
        if (!st.stopped) {
            freeze(player);
        } else if (player.getUUID().equals(st.owner)) {
            resume(player.server);
        } else {
            player.displayClientMessage(Component.translatable("message.timestopclock.busy"), true);
        }
    }

    public static void freeze(ServerPlayer player) {
        MinecraftServer server = player.server;
        TimeStopState st = TimeStopState.SERVER;
        st.clear();
        st.stopped = true;
        st.owner = player.getUUID();

        // Замораживаем смену дня/ночи, погоду и случайные тики блоков (рост растений и т.п.)
        GameRules rules = server.getGameRules();
        st.prevDaylight = rules.getBoolean(GameRules.RULE_DAYLIGHT);
        st.prevWeather = rules.getBoolean(GameRules.RULE_WEATHER_CYCLE);
        st.prevRandomTick = rules.getInt(GameRules.RULE_RANDOMTICKING);
        rules.getRule(GameRules.RULE_DAYLIGHT).set(false, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(false, server);
        rules.getRule(GameRules.RULE_RANDOMTICKING).set(0, server);

        for (ServerLevel level : server.getAllLevels()) {
            List<Entity> list = new ArrayList<>();
            level.getAllEntities().forEach(list::add);
            TimeStopHold.hold(list, st);
        }

        playForAll(server, SoundEvents.BELL_RESONATE, 2.0F, 0.5F);
        playForAll(server, SoundEvents.WARDEN_HEARTBEAT, 2.0F, 0.6F);
        player.displayClientMessage(Component.translatable("message.timestopclock.stopped"), true);
        ModNetwork.sendToAll(new SyncPacket(true, st.owner));
    }

    public static void resume(MinecraftServer server) {
        TimeStopState st = TimeStopState.SERVER;
        if (!st.stopped) return;
        st.stopped = false;

        // Возвращаем скорости замороженным сущностям
        for (Map.Entry<UUID, Vec3> en : st.vel.entrySet()) {
            Entity e = find(server, en.getKey());
            if (e != null && !(e instanceof Player)) {
                e.setDeltaMovement(en.getValue());
                e.hurtMarked = true;
            }
        }

        // Возвращаем игровые правила
        GameRules rules = server.getGameRules();
        rules.getRule(GameRules.RULE_DAYLIGHT).set(st.prevDaylight, server);
        rules.getRule(GameRules.RULE_WEATHER_CYCLE).set(st.prevWeather, server);
        rules.getRule(GameRules.RULE_RANDOMTICKING).set(st.prevRandomTick, server);

        UUID ownerId = st.owner;
        List<Map.Entry<UUID, TimeStopState.Pending>> pending = new ArrayList<>(st.pending.entrySet());
        st.clear();
        st.owner = null;

        // Все накопленные удары достигают цели одновременно
        for (Map.Entry<UUID, TimeStopState.Pending> en : pending) {
            Entity e = find(server, en.getKey());
            if (e instanceof LivingEntity living && living.isAlive()) {
                living.invulnerableTime = 0;
                living.hurt(en.getValue().source, en.getValue().amount);
            }
        }

        playForAll(server, SoundEvents.BEACON_POWER_SELECT, 2.0F, 0.8F);
        ServerPlayer owner = ownerId == null ? null : server.getPlayerList().getPlayer(ownerId);
        if (owner != null) {
            owner.displayClientMessage(Component.translatable("message.timestopclock.resumed"), true);
        }
        ModNetwork.sendToAll(new SyncPacket(false, null));
    }

    private static Entity find(MinecraftServer server, UUID id) {
        for (ServerLevel level : server.getAllLevels()) {
            Entity e = level.getEntity(id);
            if (e != null) return e;
        }
        return null;
    }

    private static void playForAll(MinecraftServer server, SoundEvent sound, float volume, float pitch) {
        for (ServerPlayer p : server.getPlayerList().getPlayers()) {
            p.playNotifySound(sound, SoundSource.PLAYERS, volume, pitch);
        }
    }

    private TimeStopManager() {}
}
