package com.example.timestopclock.time;

import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Состояние остановки времени. Отдельные экземпляры для сервера и клиента,
 * чтобы в одиночной игре (встроенный сервер) они не мешали друг другу.
 */
public final class TimeStopState {
    public static final TimeStopState SERVER = new TimeStopState();
    public static final TimeStopState CLIENT = new TimeStopState();

    public boolean stopped;
    public UUID owner;

    /** Позиции и скорости замороженных сущностей. */
    public final Map<UUID, Vec3> pos = new HashMap<>();
    public final Map<UUID, Vec3> vel = new HashMap<>();
    public final Map<UUID, Integer> fuse = new HashMap<>();
    /** Урон, накопленный за время остановки (применится при возобновлении). */
    public final Map<UUID, Pending> pending = new HashMap<>();

    public boolean prevDaylight;
    public boolean prevWeather;
    public int prevRandomTick;

    public static TimeStopState of(Level level) {
        return level.isClientSide() ? CLIENT : SERVER;
    }

    public boolean isFrozen(Entity e) {
        if (!stopped) return false;
        if (owner != null) {
            if (e.getUUID().equals(owner)) return false;
            // Транспорт, на котором едет владелец, не замораживаем
            for (Entity passenger : e.getPassengers()) {
                if (passenger.getUUID().equals(owner)) return false;
            }
        }
        return true;
    }

    public void clear() {
        pos.clear();
        vel.clear();
        fuse.clear();
        pending.clear();
    }

    public static final class Pending {
        public final DamageSource source;
        public float amount;

        public Pending(DamageSource source) {
            this.source = source;
        }
    }
}
